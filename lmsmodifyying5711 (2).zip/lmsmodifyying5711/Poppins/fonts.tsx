const Fonts = {
  SemiBoldPoppins: 'Poppins-SemiBold',
  RegularPoppins: 'Poppins-Regular',
  BoldPoppins: 'Poppins-Bold',
  LightPoppins: 'Poppins-Light',
};

export default Fonts;
