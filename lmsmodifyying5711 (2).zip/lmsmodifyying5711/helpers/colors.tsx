export const appColors = {
    default: "#EFF7FF",
    light: "#FFFFFF",
    primary: "#0055B8",
    info: "#EFF7FF",
    dark: "#1D252D",
    grey: "#868E96",
    darkGrey: "#4D454B",
    lightGrey: "#E6E6E6",
    success: "#019859",
    successLight: "#E3FCE5",
    whitesmoke: '#F5F7F9'
}